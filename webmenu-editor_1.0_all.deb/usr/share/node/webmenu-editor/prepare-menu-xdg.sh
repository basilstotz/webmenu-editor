#!/bin/sh

webmenu-xdg |  ./js/prepareMenu.js > "${HOME}/.config/webmenu/menu-xdg.json"
exit
