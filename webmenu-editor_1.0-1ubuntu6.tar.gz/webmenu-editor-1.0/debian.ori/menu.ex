?package(webmenu-editor):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="webmenu-editor" command="/usr/bin/webmenu-editor"
